import React from 'react';
import logo from './logo.svg';
import './App.css';
import List from './components/List/List';
import AddForm from './components/Form'
import ItemView from './views/ItemView'
import RootView from './views/RootView'
import SettingsView from './views/SettingsView'
import SettingsBar from './components/SettingsBar';
import axios from 'axios'
import {BrowserRouter,Route, Switch} from 'react-router-dom'
import AppContext from './Context';


let APPID = '89df1cb971afca2cd1af3ae609d46acc';

class App extends React.Component {
 
state={
    townList : [],
    unit:'metric',
    error : {
      msg:""
    }
}

convertUnit = () =>{
      
    var array = [...this.state.townList];

    if (this.state.unit === "metric")
    {
        this.toFahrenheit(array);
    }
    else 
        this.toCelsius(array);

    this.setState({townList : array});
}

toFahrenheit = (elements) =>{

    for(var i=0; i<elements.length; i++){
        elements[i].temp = (elements[i].temp * 9/5 +32).toFixed(2);
    }
    
}

toCelsius = (elements) =>{
    for(var i=0; i<elements.length; i++){
        elements[i].temp = ((elements[i].temp - 32) * 5/9).toFixed(2);
  }
}


avg = (elements) => {
    var sum=0;;
    
    for(var i=0; i<elements.length; i++){
        sum += elements[i].main.temp;
    }

    return (sum/elements.length).toFixed(2);
}


handleInputChange = (e) => {
      e.preventDefault()
      this.setState({query:e.target.value});
}


handleButtonClick = (e) =>{ 
    e.preventDefault()
    this.setState({error:false});
    
    var units_string;
    let my_error = {...this.state.error}
    let city = e.target[0].value;

    this.state.unit == 'metric' ? units_string='&units=metric' : units_string='&units=imperial';

    if ( this.townCheck(this.state.townList,e)) {
        
        my_error.msg = " Podane miasto juz istnieje";
        this.setState({error:my_error});

    }
    else {

    axios.get('http://api.openweathermap.org/data/2.5/forecast?q='+city+units_string+'&pl&mode=json&APPID=89df1cb971afca2cd1af3ae609d46acc&lang=pl')
    .then( (response) => {
      
        const item = {
            city,
            temp: this.avg(response.data.list),
            lat: response.data.city.coord.lat,
            lon: response.data.city.coord.lon,
        } 

        this.setState({
            townList:[...this.state.townList , item],
        })

    }).catch( (error) => {

      my_error.msg = "Nie znaleziono takiego miasta";
      this.setState({error:my_error});

    })  


  }
}


townCheck = (elements,e) =>{
  
  var exist = false;

  for(var i=0; i<elements.length; i++){
      if (elements[i].city.toLowerCase() === e.target[0].value.toLowerCase()) {exist = true};
  }

  return exist;
}


 handleDelete = (e,index) =>{
   var array = [...this.state.townList]
   array.splice(index,1);
   this.setState({townList:array})
   console.log(index);
 }


componentWillMount = () =>{
     localStorage.getItem('items') && this.setState({
         townList: JSON.parse(localStorage.getItem('items')),
         unit: JSON.parse(localStorage.getItem('unit')),
     })
     
}


componentWillUpdate = (nextProps,nextState) => {
      localStorage.setItem('items',JSON.stringify(nextState.townList));
   console.log('komponent zaktualizowany');
}  
  

handleUnitChange = (e) =>{
    console.log("Unit change "+e.target.value);
    this.setState({unit:e.target.value})
    localStorage.setItem('unit',JSON.stringify(e.target.value));
}


  render() {


    const contextElements = {
                              ...this.state,handleBtnClick:this.handleButtonClick,
                              handleDelete:this.handleDelete,
                              handleUnitChange:this.handleUnitChange,
                              handleInputChange:this.handleInputChange,
                              convertUnit:this.convertUnit
                            }

    return(
      <BrowserRouter>
          <AppContext.Provider value={contextElements}>
              <div className="App container">
                
                <Route path="/" component={SettingsBar}/>
                
                <Route path="/settings" component={SettingsView}/>
               
                <Route exact path="/" component={RootView}/>
                <Route  path="/itemview" component={ItemView}/>
              </div>
          </AppContext.Provider>     
      </BrowserRouter>
       
    )
  
  }
}
export default App;
