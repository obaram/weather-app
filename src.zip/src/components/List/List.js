import React from 'react';
import Listitem from './Listitem'
import { Table } from 'react-bootstrap';


const List = ({items,handleDelete}) => (

    <Table striped bordered hover>
    <thead>
        <tr>
        <th>#</th>
        <th>Miasto</th>
        <th>Średnia prognozowana temperatura</th>
        <th></th>
        </tr>
    </thead>
    <tbody>
        
        {
            items.map((item,index) => <Listitem item={item} index={index} handleDelete={handleDelete} key={index}/>)
        }
        
    </tbody>
    </Table>

)

export default List;
