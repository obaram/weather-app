import React from 'react';
import { Button } from 'react-bootstrap';
import {Link} from 'react-router-dom';
import styles from './SettingsBar.module.scss'

const SettingsBar = (props) => (

    <div className={styles.wrapper}>
        <Button variant="outline-primary"><Link to="/settings">Ustawienia</Link></Button>
    </div>

)

export default SettingsBar;