import React from 'react';
import { Button, Card } from 'react-bootstrap';
import {Link} from 'react-router-dom';
import styles from './ItemView.module.scss'

class ItemView extends React.Component {


render(){
    

    console.log(this.props.location.query);

    return(
        
        <div className={styles.wrapper}>
            
            <Card className={styles.itemcard}>
        
                
                <Card.Header as="h1">

                    {this.props.location.query.item.city}

                </Card.Header>
            
                <Card.Body>
                <p>Szerokość geograficzna: {this.props.location.query.item.lat}</p>
                <p>Długość geograficzna: {this.props.location.query.item.lon}</p>
                <p>Średnia temperatura: {this.props.location.query.item.temp}°C</p>
                <div className={styles.btnWrapper}>
                    <Button variant="outline-primary" type="submit" className="btn pull-right" ><Link to="/">Powrót</Link></Button>
                </div>
                </Card.Body>
            
            </Card>

        </div>
    )
}

}


export default ItemView;