import React from 'react';
import logo from '../logo.svg';
import List from '../components/List/List';
import AddForm from '../components/Form'
import ItemView from '../views/ItemView'
import styles from './RootView.module.scss'
import axios from 'axios'
import AppContext from '../Context'
import {BrowserRouter,Route, Switch} from 'react-router-dom'
import { Alert } from 'react-bootstrap';

let APPID = '89df1cb971afca2cd1af3ae609d46acc';

class RootView extends React.Component {


  render() {

    

    return(
      <AppContext.Consumer>
      { (context) => (


     

        <div className={styles.wrapper}>
          <AddForm handleInputChange = {context.handleInputChange} handleBtnClick = {context.handleButtonClick}/>
          {context.error.msg &&   <Alert  className={styles.alert} key="alert" variant="warning">{context.error.msg}</Alert>  }
          <List items={context.townList} handleDelete={context.handleDelete}/>

        </div>
    
      )}
      </AppContext.Consumer>

    )
  
  }
}
export default RootView;
