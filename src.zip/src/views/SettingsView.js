import React from 'react';
import {Link} from 'react-router-dom';
import { Button, InputGroup, Card } from 'react-bootstrap';
import styles from './SettingsView.module.scss'
import AppContext from '../Context'

class SettingsBar extends React.Component {

test = (value) => {
    console.log(this.props.context)
}

 render(){

    return(
    <AppContext.Consumer>
    { (context) => (
    <div className={styles.wrapper}>
        <Card className={styles.settingsCard}>
        <Card.Header as="h2">Ustawienia</Card.Header>
        <Card.Body>
            <p>Jednostka:</p>
            <InputGroup>
            <label>
                <input type="radio" name="unit" value="metric" checked={context.unit === "metric"} onChange={(e) => {
                    
                    context.handleUnitChange(e);
                    context.convertUnit();
                
                }}/>°C
            </label>
            </InputGroup>
            <InputGroup>
            <label>
                <input type="radio" name="unit" value="imperial" checked={context.unit === "imperial"}  onChange={(e) => {
                   
                   context.handleUnitChange(e);
                   context.convertUnit();

                }}/>°F
            </label>
            </InputGroup>
        <div className={styles.btnWrapper}>
        <Button variant="outline-primary" type="submit" className="btn" ><Link to="/">Powrót</Link></Button>
        </div>
        </Card.Body>
        </Card>
    </div>
    )}
    </AppContext.Consumer>

    )}
}

export default SettingsBar;